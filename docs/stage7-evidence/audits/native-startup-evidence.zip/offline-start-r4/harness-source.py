"""Owned private-desktop startup observation; no production hardware execution."""
#20261114-6 add
from pathlib import Path
import argparse, ast, ctypes, hashlib, importlib.util, json, os, queue, shutil, sys, time, winreg
import pefile, pywintypes, win32api, win32con, win32event, win32gui, win32process
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"G:\01_Professional\Frida\Installed")
import frida

ROOT = Path(r"Z:\Project\vscode_prj_temp\REA")
BASE = ROOT / ".scratch/kinseal-stage7-20261114/native-startup"
WT = ROOT / ".scratch/kinseal-stage4-20261112/worktree"
VENDOR = Path(r"G:\01_Professional\触摸屏\金玺\KinSealStudio_Setup_V5.1\Installed")
SOURCE = WT / "docs/stage1-evidence/native-analysis/bit-operation-toggle-native-ui.sm"
JS_SOURCE = WT / "docs/stage4-evidence/ascii/physical/ascii-lifecycle-r1/native_screen_probe.py"

# Trace the original launch request, but block every child before it executes.
# Offline replay uses only the exact observed executable/command/cwd, suspended
# at creation until read-only tracing and device-path blockers are installed.
MAIN_JS = r"""
const trace=[];let overflow=0;const rootPath=__ROOT__;const allowOffline=__ALLOW_OFFLINE__;
function emit(e){e.epochMs=Date.now();if(trace.length<6000){trace.push(e);}else{overflow++;}}
function readz(p,wide){if(p.isNull()){return null;}try{let n=0;while(n<8192&&(wide?p.add(n*2).readU16():p.add(n).readU8())!==0){n++;}return wide?p.readUtf16String(n):p.readCString(n);}catch(e){return '<unreadable>';}}
function back(ctx){try{return Thread.backtrace(ctx,Backtracer.ACCURATE).slice(0,14).map(p=>({address:p.toString(),symbol:DebugSymbol.fromAddress(p).toString()}));}catch(e){return [String(e)];}}
const blockedStrings=[];
for(const wide of [true,false]){
 const k=Process.getModuleByName('kernel32.dll');
 Interceptor.attach(k.getExportByName('CreateProcess'+(wide?'W':'A')),{onEnter(args){
  const si=args[8];this.pi=args[9];this.entry={api:'CreateProcess'+(wide?'W':'A'),application:readz(args[0],wide),command:readz(args[1],wide),cwd:readz(args[7],wide),flags:args[5].toUInt32(),environmentPointer:args[6].toString(),desktop:si.isNull()?null:readz(si.add(8).readPointer(),wide),backtrace:back(this.context),blocked:true};send({event:'process-create-enter',request:this.entry});
  const requested=(this.entry.command||'').replace(/\\/g,'/').toLowerCase();const allowed=(rootPath+'\\offlineSimulation\\V51_800x480.exe').replace(/\\/g,'/').toLowerCase();
  if(allowOffline&&requested.trim()===allowed){this.entry.blocked=false;this.entry.suspendedByHarness=true;args[5]=ptr(this.entry.flags|4);}
  else{const denied=wide?Memory.allocUtf16String(rootPath+'\\deliberately-absent-blocked-child.exe'):Memory.allocUtf8String(rootPath+'\\deliberately-absent-blocked-child.exe');blockedStrings.push(denied);args[0]=denied;args[1]=denied;}
 },onLeave(ret){this.entry.result=ret.toInt32();if(!this.entry.blocked&&ret.toInt32()!==0){this.entry.childPid=this.pi.add(8).readU32();this.entry.childThreadId=this.pi.add(12).readU32();send({event:'offline-child-created',pid:this.entry.childPid,threadId:this.entry.childThreadId});}emit(this.entry);}});
 Interceptor.attach(k.getExportByName('CreateFile'+(wide?'W':'A')),{onEnter(args){this.entry=null;const name=readz(args[0],wide);if(name===null){return;}const device=/^(?:\\\\[.?]\\|COM\d+(?::|$))/i.test(name);if(device){const denied=wide?Memory.allocUtf16String(rootPath+'\\deliberately-absent-blocked-device'):Memory.allocUtf8String(rootPath+'\\deliberately-absent-blocked-device');blockedStrings.push(denied);args[0]=denied;}
  if(device||/compile|NativeInput\.sm/i.test(name)){this.entry={api:'CreateFile'+(wide?'W':'A'),path:name,access:args[1].toUInt32(),disposition:args[4].toUInt32(),deviceBlocked:device};}
 },onLeave(ret){if(this.entry){this.entry.result=ret.toString();emit(this.entry);}}});
}
const socketGuards=[];
const observer=Process.attachModuleObserver({onAdded(module){if(module.name.toLowerCase()!=='ws2_32.dll'){return;}for(const [name,n] of [['connect',3],['WSAConnect',7],['send',4],['WSASend',7],['sendto',6],['WSASendTo',9]]){const address=module.findExportByName(name);if(!address){continue;}const callback=new NativeCallback(function(){emit({api:name,networkBlocked:true});return -1;},'int',Array(n).fill('pointer'),'stdcall');socketGuards.push(callback);Interceptor.replace(address,callback);}}});
for(const ex of core.enumerateExports().filter(e=>e.name.includes('QProcess')&&e.name.includes('start'))){try{Interceptor.attach(ex.address,{onEnter(args){emit({api:'QProcess',symbol:ex.name,backtrace:back(this.context)});}});}catch(e){emit({api:'QProcess-hook',symbol:ex.name,error:String(e)});}}
function metaInfo(hwnd){const object=find(ptr(hwnd));const metaFn=new NativeFunction(object.readPointer().readPointer(),'pointer',['pointer']);const meta=metaFn(object);const count=new NativeFunction(core.getExportByName('_ZNK11QMetaObject11methodCountEv'),'int',['pointer'])(meta);if(count<0||count>2000){throw Error('method count bound');}const method=new NativeFunction(core.getExportByName('_ZNK11QMetaObject6methodEi'),'uint64',['pointer','int']);const signature=new NativeFunction(core.getExportByName('_ZNK11QMetaMethod9signatureEv'),'pointer',['pointer']);const methods=[];for(let i=0;i<count;i++){const result=Memory.alloc(16);result.writeU64(method(meta,i));const value=signature(result).readCString();if(/offline|online|simulation|monitor/i.test(value)){methods.push({index:i,signature:value});}}
 const callAddress=object.readPointer().add(8).readPointer();Interceptor.attach(callAddress,{onEnter(args){if(Process.getCurrentThreadId()!==guiThread){return;}const id=args[2].toInt32();const matching=methods.find(m=>m.index===id);if(matching){emit({api:'qt_metacall',id,call:args[1].toInt32(),signature:matching.signature,address:callAddress.toString(),backtrace:back(this.context)});}}});return {className:kind(object),metaObject:meta.toString(),qtMetaCall:callAddress.toString(),methodCount:count,methods};}
"""

CHILD_JS = r"""
const rows=[];let overflow=0;const handles=new Map();const blockers=[];const rootPath=__ROOT__;
function emit(e){e.epochMs=Date.now();if(rows.length<6000){rows.push(e);}else{overflow++;}}
function cstring(p){try{if(p.isNull()){return null;}let n=0;while(n<1024&&p.add(n).readU8()!==0){n++;}return p.readCString(n);}catch(e){return '<unreadable>';}}
const observation=Process.attachModuleObserver({onAdded(module){if(module.name.toLowerCase()==='ws2_32.dll'){for(const [name,n] of [['connect',3],['WSAConnect',7],['send',4],['WSASend',7],['sendto',6],['WSASendTo',9]]){const address=module.findExportByName(name);if(!address){continue;}const callback=new NativeCallback(function(){emit({api:name,networkBlocked:true});return -1;},'int',Array(n).fill('pointer'),'stdcall');blockers.push(callback);Interceptor.replace(address,callback);}return;}if(module.name.toLowerCase()!=='msvcr100.dll'){return;}
 for(const name of ['fopen','fread','fseek','fclose']){const address=module.findExportByName(name);if(!address){continue;}Interceptor.attach(address,{onEnter(args){this.name=name;this.data={api:name};if(name==='fopen'){this.data.path=cstring(args[0]);this.data.mode=cstring(args[1]);if(/^(?:\\\\[.?]\\|COM\d+(?::|$))/i.test(this.data.path||'')){const value=Memory.allocUtf8String(rootPath+'\\deliberately-absent-blocked-device');blockers.push(value);args[0]=value;this.data.deviceBlocked=true;}}
  else if(name==='fread'){this.data.handle=args[3].toString();this.data.path=handles.get(this.data.handle)||null;this.data.size=args[1].toUInt32();this.data.count=args[2].toUInt32();}
  else{this.data.handle=args[0].toString();this.data.path=handles.get(this.data.handle)||null;}
 },onLeave(ret){this.data.result=ret.toString();if(this.name==='fopen'&&!ret.isNull()){handles.set(ret.toString(),this.data.path);}if(this.name==='fread'){this.data.bytesRead=ret.toUInt32()*this.data.size;}emit(this.data);}});}
}});
rpc.exports={events(){return {events:rows,overflow,modules:Process.enumerateModules().map(m=>({name:m.name,path:m.path})),main:{path:Process.mainModule.path,base:Process.mainModule.base.toString(),size:Process.mainModule.size}};}};
"""


def sha(path):
    """Hash the exact file used by this owned run."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    """Preserve structured evidence in the owned task root."""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def inventory(path):
    """Record complete hashes of generated task-local file inputs."""
    return [{"path": str(p.relative_to(path)), "bytes": p.stat().st_size, "sha256": sha(p)}
            for p in sorted(path.rglob("*")) if p.is_file()]


def main():
    """Observe one bounded startup mode on an owned desktop and terminate owned PIDs."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["offline-cancel", "offline-start", "online-config"], required=True)
    parser.add_argument("--run", choices=["r1", "r2", "r3", "r4", "r5"], default="r1")
    parser.add_argument("--compile-first", action="store_true")
    args = parser.parse_args()
    out = BASE / (args.mode + "-" + args.run);out.mkdir()
    work = out / "runtime";work.mkdir()
    temp = out / "temp";temp.mkdir()
    env = dict(os.environ, TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONDONTWRITEBYTECODE="1")
    record = {"mode": args.mode, "startedEpoch": time.time(), "status": "preparing",
              "privateDesktopOnly": True, "globalInput": False, "hardwareTransferExecuted": False,
              "childLaunchPolicy": "Only exact owned offline path may start, with CREATE_SUSPENDED until tracing is installed; all other child requests blocked",
              "steps": [], "snapshots": []}
    process = thread = session = script = child_process = child_thread = child_session = child_script = None
    desk = None
    try:
        raw = (VENDOR / "KinSealStudio5.1.exe").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == "305592b4e4bc1b15a707c7bc832c31f27ca0958b97f9c79a5b50ac6df49e907c"
        shared = BASE / "shared";shared.mkdir(exist_ok=True)
        private = bytearray(raw);assert private[0x7c4:0x7c7] == bytes.fromhex("5589e5")
        private[0x7c4:0x7c7] = bytes.fromhex("b001c3")
        executable = shared / "KinSealStudio5.1-private.exe"
        if not executable.exists():executable.write_bytes(private)
        assert sha(executable) == "38100bf47294342119560dadfbd6a35d6ab51180c0eeaf4b7b21517bea20ed89"
        exe = work / executable.name;os.link(executable, exe)
        for name in ["model.dat", "modelInfo.dat", "language.ini"]:shutil.copy2(VENDOR / name, work / name)
        for folder in ["codecs", "imageformats", "iconengines"]:
            (work / folder).mkdir()
            for file in (VENDOR / folder).glob("*4.dll"):
                if not file.name.endswith("d4.dll"):shutil.copy2(file, work / folder / file.name)
        (work / "PlcDll").mkdir();shutil.copy2(VENDOR / "PlcDll/Modbus_RTU.dll", work / "PlcDll/Modbus_RTU.dll")
        (work / "offlineSimulation").mkdir()
        shutil.copy2(VENDOR / "offlineSimulation/V51_800x480.exe", work / "offlineSimulation/V51_800x480.exe")
        loader = importlib.util.spec_from_file_location("stage6_guard_recipe", ROOT / ".scratch/kinseal-stage6-20261114/native-ui-media/media_probe.py")
        guard = importlib.util.module_from_spec(loader);loader.loader.exec_module(guard)
        record["hardwareBlockers"] = [
            guard.private_libusb(VENDOR / "libusb0.dll", work / "libusb0.dll", {"usb_init":0,"usb_find_busses":0,"usb_find_devices":0,"usb_get_busses":0,"usb_open":0,"usb_bulk_read":-5,"usb_bulk_write":-5,"usb_control_msg":-5,"usb_submit_async":-5}),
            guard.private_libusb(VENDOR / "DownT.dll", work / "DownT.dll", {"Usb_connect":0,"Usb_init":0,"Usb_readRaw":-5,"Usb_writeRaw":-5})]
        source = work / "NativeInput.sm";shutil.copy2(SOURCE, source)
        assert sha(source) == "ee2e1a80937f254ba954de8e0277a460497d1dacabdf83cd0c2a4e99feeb0d73"
        record["input"] = {"origin":str(SOURCE),"path":str(source),"beforeSha256":sha(source),"beforeBytes":source.stat().st_size}
        tree = ast.parse(JS_SOURCE.read_text(encoding="utf-8"))
        js = ast.literal_eval(next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "JS" for t in n.targets)))
        js = js.replace("function execute(p){", "function execute(p){if(p.op==='meta'){return metaInfo(p.hwnd);}", 1)
        js = js.replace("rpc.exports={", "rpc.exports={events(){return {events:trace,overflow};},loadGuardedModule(path){return Module.load(path).name;},moduleIdentities(){return Process.enumerateModules().filter(m=>/^(libusb0|DownT)\\.dll$/i.test(m.name)).map(m=>({name:m.name,path:m.path}));},", 1)
        js += MAIN_JS.replace("__ROOT__", json.dumps(str(work))).replace("__ALLOW_OFFLINE__", "true" if args.mode=="offline-start" else "false")
        shutil.copy2(Path(__file__), out / "harness-source.py")
        write(out / "probe-sources.json", {"baseJs":str(JS_SOURCE),"baseJsSha256":sha(JS_SOURCE),"harness":str(out / "harness-source.py"),"harnessSha256":sha(Path(__file__)),"fridaVersion":frida.__version__})
        desktop = "KinSealStage7_" + args.mode.replace("-", "_") + "_" + args.run
        user = ctypes.WinDLL("user32", use_last_error=True)
        user.CreateDesktopW.argtypes = [ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];user.CreateDesktopW.restype=ctypes.c_void_p;user.CloseDesktop.argtypes=[ctypes.c_void_p]
        desk = user.CreateDesktopW(desktop,None,None,0,0x000F01FF,None);assert desk
        startup = win32process.STARTUPINFO();startup.lpDesktop="WinSta0\\"+desktop;startup.dwFlags=win32con.STARTF_USESHOWWINDOW;startup.wShowWindow=win32con.SW_SHOWNORMAL
        env.update(PATH=str(VENDOR)+os.pathsep+env.get("PATH",""),__COMPAT_LAYER="RunAsInvoker")
        process,thread,pid,_ = win32process.CreateProcess(str(exe),'"%s" "%s"'%(exe,source),None,None,False,win32process.CREATE_UNICODE_ENVIRONMENT,env,str(work),startup)
        record["pid"]=pid;record["desktop"]=startup.lpDesktop

        def windows(selected_pid):
            """Enumerate only windows belonging to an owned PID on the private desktop."""
            found=[]
            win32gui.EnumDesktopWindows(pywintypes.HANDLE(desk),lambda h,_:found.append(h) if win32process.GetWindowThreadProcessId(h)[1]==selected_pid else None,None)
            return found

        editor = menu = None;deadline=time.time()+24
        while time.time()<deadline:
            for top in windows(pid):
                children=[];win32gui.EnumChildWindows(top,lambda h,_:children.append(h),None)
                menus=[h for h in children if win32gui.GetWindowText(h)=="menuBar"]
                if menus:editor=top;menu=menus[0];break
            if editor:break
            time.sleep(.2)
        assert editor,"Private editor not created"
        pending_children=queue.Queue()

        def on_message(message, data):
            """Queue owned suspended-child notifications without blocking Frida callbacks."""
            if message.get("type")=="send" and message.get("payload",{}).get("event")=="offline-child-created":
                pending_children.put(message["payload"])
            elif message.get("type")=="send" and message.get("payload",{}).get("event")=="process-create-enter":
                record.setdefault("nativeLaunchEnter",[]).append(message["payload"]["request"])
            elif message.get("type")=="error":record.setdefault("fridaErrors",[]).append(message)

        session=frida.attach(pid);script=session.create_script(js);script.on("message",on_message);script.load();api=script.exports_sync
        api.set_thread(win32process.GetWindowThreadProcessId(menu)[0]);api.load_guarded_module(str(work/"DownT.dll"))
        modules=api.module_identities();record["loadedHardwareModules"]=modules
        assert len(modules)==2 and all(Path(x["path"]).resolve().parent==work.resolve() for x in modules)

        def service_child():
            """Install read tracing on the exact native-created offline child before resume."""
            nonlocal child_process,child_thread,child_session,child_script
            while not pending_children.empty():
                notice=pending_children.get_nowait()
                assert child_process is None,"Unexpected repeated native child"
                child_process=win32api.OpenProcess(0x00100000|0x0400|0x0001|0x0010,False,notice["pid"])
                child_thread=win32api.OpenThread(0x0002|0x0040,False,notice["threadId"])
                child_session=frida.attach(notice["pid"])
                child_script=child_session.create_script(CHILD_JS.replace("__ROOT__",json.dumps(str(work))));child_script.load()
                identity=child_script.exports_sync.events()["main"]
                assert Path(identity["path"]).resolve()==(work/"offlineSimulation/V51_800x480.exe").resolve()
                assert sha(Path(identity["path"]))=="6e4e104e552869e0e4139d2d4db2a3bdf9383eed8c29a2b64d3300b607c5df7f"
                record["offlineRuntime"]={"pid":notice["pid"],"threadId":notice["threadId"],"identity":identity,"traceInstalledBeforeResume":True,"resumePriorSuspendCount":win32process.ResumeThread(child_thread)}

        def op(request):
            """Queue one Qt operation to the owned editor thread without global input."""
            service_child();serial=api.queue(request);win32gui.PostMessage(menu,win32con.WM_NULL,0,0);limit=time.time()+6
            while time.time()<limit:
                service_child()
                result=api.poll()
                if result and result["serial"]==serial:
                    record["steps"].append({"request":request,"result":result});assert result["status"]=="completed",result;return result["value"]
                time.sleep(.04)
            raise RuntimeError("GUI operation timed out: "+str(request))

        def snapshot(label):
            """Read true Qt fields in the owned private windows."""
            rows=[]
            for top in windows(pid):
                if not win32gui.IsWindowVisible(top):continue
                children=[top];win32gui.EnumChildWindows(top,lambda h,_:children.append(h),None)
                rows.append({"hwnd":top,"title":win32gui.GetWindowText(top),"class":win32gui.GetClassName(top),"widgets":op({"op":"batch","hwnds":children})})
            record["snapshots"].append({"label":label,"windows":rows});record["trace"]=api.events();write(out/"run.json",record)
            return rows

        def flat(rows):
            """Traverse the already observed QAction tree."""
            for row in rows:yield row;yield from flat(row.get("children",[]))

        record["metaObject"]=op({"op":"meta","hwnd":editor})
        menus=op({"op":"menus","hwnd":menu});actions=[x for x in flat(menus) if x["objectName"] in ["action_offline_simulation","action_online_simulation"]]
        record["actions"]=actions;assert len(actions)==2 and all(x["enabled"] for x in actions)
        if args.compile_first:
            compile_action=next(x for x in flat(menus) if x["objectName"]=="action_USBdownload")
            assert compile_action["enabled"]
            record["explicitNativeCompileFirst"]=True
            record["explicitCompileEntry"]=compile_action
            op({"op":"invoke","pointer":compile_action["pointer"],"slot":"trigger"});time.sleep(1)
            compile_rows=snapshot("after-explicit-native-compile")
            for row in compile_rows:
                roots=[x.get("qt",{}) for x in row["widgets"] if x["hwnd"]==row["hwnd"]]
                if roots and roots[0].get("kind") not in ["MainWindow","QWidget"]:
                    op({"op":"invoke","hwnd":row["hwnd"],"slot":"close"})
            time.sleep(.2)
        snapshot("before-entry")
        selected=next(x for x in actions if x["objectName"]==("action_online_simulation" if args.mode=="online-config" else "action_offline_simulation"))
        op({"op":"invoke","pointer":selected["pointer"],"slot":"trigger"});time.sleep(.7)
        rows=snapshot("after-entry")
        buttons=[x for r in rows for x in r["widgets"] if x.get("qt",{}).get("kind")=="QPushButton" and x["qt"].get("visible")]
        record["entryButtons"]=buttons
        choose=["取消","Cancel","&Cancel","否","&No","No"] if args.mode=="offline-cancel" else ["确定","确认","&Yes","Yes","是","&OK","OK"]
        matching=[x for x in buttons if x["qt"].get("text") in choose]
        if len(matching)==1:
            op({"op":"invoke","hwnd":matching[0]["hwnd"],"slot":"click"});record["entryDecision"]=matching[0]["qt"];time.sleep(1)
        rows=snapshot("after-entry-decision")
        record["input"]["afterDecisionSha256"]=sha(source)
        record["generatedFiles"]=inventory(work/"compile") if (work/"compile").exists() else []
        requests=[x for x in api.events()["events"] if x.get("api") in ["CreateProcessW","CreateProcessA"]]
        record["launchRequests"]=requests
        if args.mode=="offline-start":
            assert requests,"No native offline launch request observed"
            service_child();assert child_process is not None,"Native suspended child was not observed"
            assert requests[0]["result"]!=0 and not requests[0]["blocked"]
            child_pid=record["offlineRuntime"]["pid"]
            record["offlineRuntime"]["inputFilesBefore"]=inventory(work/"compile") if (work/"compile").exists() else []
            child_api=child_script.exports_sync
            time.sleep(1)
            child_windows=windows(child_pid)
            record["offlineRuntime"]["windows"]=[{"hwnd":h,"title":win32gui.GetWindowText(h),"class":win32gui.GetClassName(h),"visible":win32gui.IsWindowVisible(h),"rect":win32gui.GetWindowRect(h),"clientRect":win32gui.GetClientRect(h)} for h in child_windows]
            record["offlineRuntime"]["trace"]=child_api.events()
            for handle in child_windows:
                if win32gui.IsWindowVisible(handle):win32gui.PostMessage(handle,win32con.WM_CLOSE,0,0)
            win32event.WaitForSingleObject(child_process,5000)
            record["offlineRuntime"]["exitCodeAfterClose"]=win32process.GetExitCodeProcess(child_process)
            record["offlineRuntime"]["inputFilesAfter"]=inventory(work/"compile") if (work/"compile").exists() else []
        record["input"]["afterSha256"]=sha(source);record["status"]="observed"
    except Exception as error:
        record["status"]="partial-or-error";record["error"]=repr(error)
    finally:
        if "input" in record and Path(record["input"]["path"]).exists():
            record["input"]["finalSha256"] = sha(Path(record["input"]["path"]))
        if script:
            try:record["trace"]=script.exports_sync.events()
            except Exception as error:record["traceReadError"]=repr(error)
        for label,owned in [("offlineRuntime",child_process),("editor",process)]:
            if owned:
                prior=win32process.GetExitCodeProcess(owned)
                if prior==259:win32process.TerminateProcess(owned,0)
                win32event.WaitForSingleObject(owned,5000)
                record.setdefault("cleanup",{})[label]={"exitCodeBeforeForcedCleanup":prior,"terminated":win32process.GetExitCodeProcess(owned)!=259}
        for attached in [child_session,session]:
            if attached:
                try:attached.detach()
                except Exception:pass
        for handle in [child_thread,child_process,thread,process]:
            if handle:handle.Close()
        if desk:user.CloseDesktop(desk)
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r"Software\KinSealStudio\recent pro files",0,winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
                recent,kind=winreg.QueryValueEx(key,"recentFileList");prefix=str(work).replace("\\","/").casefold()+"/"
                kept=[x for x in recent if not x.replace("\\","/").casefold().startswith(prefix)]
                if kind==winreg.REG_MULTI_SZ and len(kept)!=len(recent):winreg.SetValueEx(key,"recentFileList",0,kind,kept)
                record["ownMruCleanup"]={"removed":len(recent)-len(kept),"otherEntriesPreserved":len(kept)}
        except OSError as error:record["ownMruCleanup"]={"error":repr(error)}
        record["endedEpoch"]=time.time();write(out/"run.json",record)
    print(json.dumps({"mode":args.mode,"status":record["status"],"error":record.get("error"),"requests":record.get("launchRequests"),"out":str(out)},ensure_ascii=False))
    return 0 if record["status"]=="observed" else 1


if __name__=="__main__":raise SystemExit(main())
