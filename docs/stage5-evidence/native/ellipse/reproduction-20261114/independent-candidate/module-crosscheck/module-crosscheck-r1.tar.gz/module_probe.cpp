#include "Z:/Project/vscode_prj_temp/REA/.scratch/kinseal-stage4-20261112/worktree/src/device_ellipse_raster.cpp"
#include <QCoreApplication>
#include <QDataStream>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>
int main(int argc,char **argv)
{
    QCoreApplication app(argc,argv);
    QFile input;
    QFile output;
    QDataStream stream;
    QPainterPath source;
    QPainterPath flattened;
    QPainterPath integerPath;
    QPainterPath fractionalPath;
    QByteArray mask;
    QByteArray expected;
    QString error;
    bool result;
    if (argc==3)
    {
        input.setFileName(QString::fromLocal8Bit(argv[1]));if(!input.open(QIODevice::ReadOnly)){return 2;}
        stream.setDevice(&input);stream.setVersion(QDataStream::Qt_4_8);stream>>source;
        if(stream.status()!=QDataStream::Ok || !ellipseFlattenPath(source,&flattened,&error,nullptr)
            || !deviceStraightPathCoverage(flattened,DeviceStraightCoveragePrecision::Exact8Bit,&mask,&error))
        {std::fprintf(stderr,"%s\n",error.toUtf8().constData());return 3;}
        output.setFileName(QString::fromLocal8Bit(argv[2]));if(!output.open(QIODevice::WriteOnly)||output.write(mask)!=800*480){return 4;}
        return 0;
    }
    if (argc!=1){return 5;}
    integerPath.addRect(QRectF(100,100,100,100));fractionalPath.addRect(QRectF(100.0+1.0/512.0,100,100,100));
    if(!deviceStraightPathCoverage(integerPath,DeviceStraightCoveragePrecision::Quantized26_6,&expected,&error)){return 6;}
    if(!deviceStraightPathCoverage(fractionalPath,DeviceStraightCoveragePrecision::Quantized26_6,&mask,&error)||mask!=expected){return 7;}
    mask="sentinel";result=deviceStraightPathCoverage(fractionalPath,DeviceStraightCoveragePrecision::Exact8Bit,&mask,&error);
    if(result || mask!="sentinel" || error.isEmpty()){return 8;}
    source.addEllipse(QRectF(100,100,200,100));result=deviceStraightPathCoverage(source,DeviceStraightCoveragePrecision::Exact8Bit,&mask,&error);
    if(result || mask!="sentinel" || error.isEmpty()){return 9;}
    result=deviceStraightPathCoverage(integerPath,static_cast<DeviceStraightCoveragePrecision>(99),&mask,&error);
    if(result || mask!="sentinel" || error.isEmpty()){return 10;}
    std::printf("{\"legacy26_6FractionPreserved\":true,\"non8BitRejectedAtomically\":true,\"curvesRejectedAtomically\":true,\"unknownPrecisionRejectedAtomically\":true}\n");
    return 0;
}
