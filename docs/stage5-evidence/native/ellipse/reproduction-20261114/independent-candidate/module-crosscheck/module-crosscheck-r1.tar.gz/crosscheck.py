from pathlib import Path
import hashlib,json,os,subprocess
here=Path(__file__).resolve().parent;algorithm=here.parent;root=algorithm.parent;work=root.parent/'kinseal-stage4-20261112/worktree'
qt=Path('G:/01_Professional/QT6/Installed/6.12.0/mingw_64');mingw=Path('G:/01_Professional/QT6/Installed/Tools/mingw1310_64/bin')
env=os.environ.copy();env['PATH']=str(mingw)+';'+str(qt/'bin')+';'+env.get('PATH','')
for key in ('TEMP','TMP','TMPDIR'):env[key]=str(here/'temp')
command=[str(mingw/'g++.exe'),'-std=c++17','-O2','-Wall','-Wextra','-Wconversion','-DQT_NO_DEBUG','-isystem',str(qt/'include'),'-isystem',str(qt/'include/QtCore'),'-isystem',str(qt/'include/QtGui'),str(here/'module_probe.cpp'),str(work/'src/device_polygon_raster.cpp'),'-L'+str(qt/'lib'),'-lQt6Gui','-lQt6Core','-o',str(here/'module_probe.exe')]
r=subprocess.run(command,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW);(here/'build-r1.log').write_bytes(r.stdout+r.stderr)
if r.returncode:raise RuntimeError((r.returncode,(r.stdout+r.stderr).decode(errors='replace')))
old=json.loads((algorithm/'cpp-ellipse-coverage-r1.json').read_text(encoding='utf-8'));records=[]
for case in old['cases']:
 label=case['case'];layer=case['layer'];source=algorithm/'artifacts'/label/(label+'-'+layer+'.pathstream');destination=here/'temp'/(label+'-'+layer+'.mask')
 cmd=[str(here/'module_probe.exe'),str(source),str(destination)];r=subprocess.run(cmd,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
 if r.returncode:raise RuntimeError((cmd,r.returncode,r.stderr))
 raw=destination.read_bytes();actual=hashlib.sha256(raw).hexdigest();records.append(dict(case=label,layer=layer,bytes=len(raw),actualSha256=actual,retainedOracleSha256=case['oracleCoverageSha256'],equal=actual==case['oracleCoverageSha256']))
r=subprocess.run([str(here/'module_probe.exe')],env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
if r.returncode:raise RuntimeError((r.returncode,r.stdout,r.stderr))
result=dict(cases=records,allCoverageEqual=all(c['equal'] for c in records),helperGuards=json.loads(r.stdout),compileCommand=command,compileExitCode=0,buildLogBytes=(here/'build-r1.log').stat().st_size,productionSha256={name:hashlib.sha256((work/'src'/name).read_bytes()).hexdigest() for name in ('device_polygon_raster.h','device_polygon_raster.cpp','device_ellipse_raster.h','device_ellipse_raster.cpp')},nativeProcessLaunched=False,usbAccessed=False,mainBuildInvoked=False)
(here/'module-mask-crosscheck-r1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(cases=len(records),allCoverageEqual=result['allCoverageEqual'],helperGuards=result['helperGuards'],buildLogBytes=result['buildLogBytes'])))
if not result['allCoverageEqual']:raise SystemExit(1)
