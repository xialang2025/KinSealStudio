"""Archive this owned candidate reproducibly and remove only its explicit regenerated temporary files."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import platform
import tarfile
import numpy as np

HERE = Path(__file__).resolve().parent
TEMP = (HERE / 'temp').resolve()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    archive_path = HERE / 'ellipse-algorithm-reproduction-r1.tar.gz'
    manifest_path = HERE / 'reproduction-manifest-r1.json'
    receipt_path = HERE / 'cleanup-r1.json'
    if archive_path.exists() or manifest_path.exists() or receipt_path.exists():
        raise ValueError('This reproduction version already exists; do not overwrite its receipt.')
    content = {}
    for path in sorted(HERE.rglob('*')):
        if not path.is_file() or path.resolve().is_relative_to(TEMP):
            continue
        if path.suffix not in ('.cpp', '.h', '.py', '.exe', '.log', '.json', '.md', '.pathstream'):
            raise ValueError('Unexpected owned file before archive: ' + str(path))
        if path.is_symlink():
            raise ValueError('Refuse redirected candidate evidence: ' + str(path))
        content[path.relative_to(HERE).as_posix()] = path.read_bytes()
    manifest = dict(scope='Independent C++ ellipse subdivision candidate; no production support claim.',
                    python=platform.python_version(), numpy=np.__version__,
                    files=[dict(path=name, bytes=len(raw), sha256=digest(raw)) for name, raw in content.items()],
                    nativeProcessLaunched=False, usbAccessed=False, productionChanged=False)
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
    manifest_path.write_bytes(raw_manifest)
    content[manifest_path.name] = raw_manifest
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, raw in sorted(content.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mtime = 0
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    compressed = gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0)
    archive_path.write_bytes(compressed)
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)), mode='r:') as archive:
        if set(archive.getnames()) != set(content):
            raise ValueError('Reproduction archive member set differs.')
        for name, raw in content.items():
            if digest(archive.extractfile(name).read()) != digest(raw):
                raise ValueError('Reproduction archive member hash differs: ' + name)
    planned_names = {'default-native.rgb565'}
    for label in ('default', 'shift', 'wide', 'tall', 'odd', 'min100', 'far', 'near'):
        for layer in ('fill', 'stroke'):
            planned_names.add(label + '-' + layer + '.mask')
            planned_names.add(label + '-' + layer + '.mask.pathstream')
    removed = []
    if TEMP.parent != HERE.resolve():
        raise ValueError('Temporary directory resolved outside the owned candidate root.')
    for name in sorted(planned_names):
        path = TEMP / name
        if path.resolve().parent != TEMP or path.is_symlink():
            raise ValueError('Temporary cleanup path was redirected.')
        if path.is_file():
            raw = path.read_bytes()
            removed.append(dict(path=str(path), bytes=len(raw), sha256=digest(raw)))
    unexpected = [str(path) for path in TEMP.iterdir() if path.name not in planned_names]
    if unexpected:
        raise ValueError('Unexpected temporary files are not authorized for deletion: ' + str(unexpected))
    for item in removed:
        path = Path(item['path'])
        if digest(path.read_bytes()) != item['sha256']:
            raise ValueError('Temporary identity changed after the cleanup plan.')
        path.unlink()
    receipt = dict(archive=archive_path.name, archiveBytes=len(compressed), archiveSha256=digest(compressed),
                   archivedMembers=len(content), everyArchiveMemberRoundTripSha256Verified=True,
                   removedFiles=removed, removedBytes=sum(item['bytes'] for item in removed),
                   remainingTemporaryFiles=[str(path) for path in TEMP.iterdir()],
                   cDriveFilesDeleted=0, nativeProcessLaunched=False, usbAccessed=False, productionChanged=False)
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'removedFiles'}))


if __name__ == '__main__':
    main()
