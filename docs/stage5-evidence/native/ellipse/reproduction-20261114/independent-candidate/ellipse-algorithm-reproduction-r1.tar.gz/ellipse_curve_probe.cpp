#include "ellipse_curve_candidate.h"

#include <QCoreApplication>
#include <QDataStream>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPainterPathStroker>
#include <cstdio>

/******************************************************************************
 * Function Name   : writePath
 * Description     : Preserve independent and flattened geometry in the existing diagnostic stream format.
 * Input Parameters: fileName, path
 * Return Value    : True if all path bytes were written successfully.
 * Date            : 2026.11.14
 ******************************************************************************/
static bool writePath(const QString &fileName, const QPainterPath &path) //20261114-5 add
{
    QFile file(fileName);
    QDataStream stream;

    if (!file.open(QIODevice::WriteOnly))
    {
        return false;
    }
    stream.setDevice(&file);
    stream.setVersion(QDataStream::Qt_4_8);
    stream << path;
    return stream.status() == QDataStream::Ok;
}

/******************************************************************************
 * Function Name   : detailsJson
 * Description     : Expose exact integer subdivision choices for cross-language verification.
 * Input Parameters: stats
 * Return Value    : Diagnostic JSON object.
 * Date            : 2026.11.14
 ******************************************************************************/
static QJsonObject detailsJson(const EllipseFlattenStats &stats) //20261114-5 add
{
    QJsonObject result;
    QJsonArray depths;
    qint64 index;

    for (index = 0; index < stats.depths.size(); index++)
    {
        depths.append(stats.depths.at(int(index)));
    }
    result.insert(QStringLiteral("inputElements"), stats.inputElements);
    result.insert(QStringLiteral("generatedElements"), stats.generatedElements);
    result.insert(QStringLiteral("extentX"), stats.extentX);
    result.insert(QStringLiteral("extentY"), stats.extentY);
    result.insert(QStringLiteral("adaptation"), stats.adaptation);
    result.insert(QStringLiteral("cubicThreshold"), stats.cubicThreshold);
    result.insert(QStringLiteral("thirdThreshold"), stats.thirdThreshold);
    result.insert(QStringLiteral("depths"), depths);
    return result;
}

/******************************************************************************
 * Function Name   : main
 * Description     : Generate an independent ellipse and width-one stroke, then flatten both safely.
 * Input Parameters: output prefix, integer x, y, width, height
 * Return Value    : Zero on success; nonzero without successful output claims on refusal.
 * Date            : 2026.11.14
 ******************************************************************************/
int main(int argc, char **argv) //20261114-5 add
{
    QCoreApplication app(argc, argv);
    QPainterPath fill;
    QPainterPath stroke;
    QPainterPath flatFill;
    QPainterPath flatStroke;
    QPainterPathStroker stroker;
    EllipseFlattenStats fillStats;
    EllipseFlattenStats strokeStats;
    QJsonObject result;
    QFile report;
    QString prefix;
    QString error;
    qint64 coordinates[4];
    qint64 index;
    bool valid;

    if (argc != 6)
    {
        std::fprintf(stderr, "Usage: ellipse_curve_probe prefix x y width height\n");
        return 2;
    }
    for (index = 0; index < 4; index++)
    {
        coordinates[index] = QString::fromLocal8Bit(argv[index + 2]).toLongLong(&valid);
        if (!valid || coordinates[index] < 1 || coordinates[index] > (index % 2 == 0 ? 799 : 479))
        {
            std::fprintf(stderr, "Integer geometry outside the bounded diagnostic range.\n");
            return 3;
        }
    }
    if (coordinates[2] < 100 || coordinates[3] < 100
            || coordinates[0] + coordinates[2] > 799 || coordinates[1] + coordinates[3] > 479)
    {
        std::fprintf(stderr, "Ellipse is smaller than 100x100 or extends past the tested screen range.\n");
        return 3;
    }
    prefix = QString::fromLocal8Bit(argv[1]);
    fill.addEllipse(QRectF(qreal(coordinates[0]), qreal(coordinates[1]), qreal(coordinates[2]), qreal(coordinates[3])));
    stroker.setWidth(1);
    stroker.setCapStyle(Qt::SquareCap);
    stroker.setJoinStyle(Qt::BevelJoin);
    stroke = stroker.createStroke(fill);
    if (!flattenHistoricalEllipseCandidate(fill, &flatFill, &error, &fillStats)
            || !flattenHistoricalEllipseCandidate(stroke, &flatStroke, &error, &strokeStats))
    {
        std::fprintf(stderr, "%s\n", error.toUtf8().constData());
        return 4;
    }
    if (!writePath(prefix + QStringLiteral("-fill.pathstream"), fill)
            || !writePath(prefix + QStringLiteral("-stroke.pathstream"), stroke)
            || !writePath(prefix + QStringLiteral("-fill-flat.pathstream"), flatFill)
            || !writePath(prefix + QStringLiteral("-stroke-flat.pathstream"), flatStroke))
    {
        std::fprintf(stderr, "Unable to write one of the diagnostic path streams.\n");
        return 5;
    }
    result.insert(QStringLiteral("fill"), detailsJson(fillStats));
    result.insert(QStringLiteral("stroke"), detailsJson(strokeStats));
    result.insert(QStringLiteral("scope"), QStringLiteral("Independent geometry candidate only; not native validation or production support."));
    report.setFileName(prefix + QStringLiteral("-details.json"));
    if (!report.open(QIODevice::WriteOnly)
            || report.write(QJsonDocument(result).toJson(QJsonDocument::Indented)) < 0)
    {
        return 6;
    }
    return 0;
}
