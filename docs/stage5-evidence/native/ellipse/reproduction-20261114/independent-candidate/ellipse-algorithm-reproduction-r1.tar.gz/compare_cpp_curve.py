"""Compare independent C++ ellipse subdivision with full diagnostic coverage masks.

The historical raster executable is an external diagnostic oracle only. Native
processes and devices are never started or accessed by this program.
"""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import numpy as np
from area_candidate_256 import coverage
from ellipse_reference import make_flat, compose

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORK = ROOT.parent / 'kinseal-stage4-20261112/worktree'
TEMP = HERE / 'temp'
ARTIFACTS = HERE / 'artifacts'
ENV = os.environ.copy()
ENV['PATH'] = 'G:/01_Professional/QT6/Installed/6.12.0/mingw_64/bin;G:/01_Professional/QT6/Installed/Tools/mingw1310_64/bin;' + ENV.get('PATH', '')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    ENV[key] = str(TEMP)


def call(command, required_exit=0):
    result = subprocess.run(list(map(str, command)), env=ENV, capture_output=True,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode != required_exit:
        raise RuntimeError((command, result.returncode, result.stdout, result.stderr))
    return result


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    TEMP.mkdir(exist_ok=True)
    ARTIFACTS.mkdir(exist_ok=True)
    cases = [
        ('default', (100, 100, 200, 100)),
        ('shift', (75, 65, 160, 120)),
        ('wide', (100, 100, 300, 150)),
        ('tall', (100, 100, 120, 250)),
        ('odd', (100, 100, 201, 101)),
        ('min100', (100, 100, 100, 100)),
        ('far', (498, 278, 200, 100)),
        ('near', (2, 2, 200, 100)),
    ]
    records, commands, masks = [], [], {}
    for label, geometry in cases:
        folder = ARTIFACTS / label
        folder.mkdir(exist_ok=True)
        prefix = folder / label
        command = [HERE / 'ellipse_curve_probe.exe', prefix, *geometry]
        call(command)
        commands.append(list(map(str, command)))
        details = json.loads(Path(str(prefix) + '-details.json').read_text(encoding='utf-8'))
        for layer in ('fill', 'stroke'):
            independent_path = Path(str(prefix) + '-' + layer + '.pathstream')
            cpp_flat = Path(str(prefix) + '-' + layer + '-flat.pathstream')
            mask_path = TEMP / (label + '-' + layer + '.mask')
            command = [ROOT / 'legacy_coverage_probe.exe', mask_path, 'ellipse', 'fill', independent_path]
            call(command)
            commands.append(list(map(str, command)))
            oracle_raw = mask_path.read_bytes()
            oracle = np.frombuffer(oracle_raw, np.uint8).reshape(480, 800)
            cpp = coverage(cpp_flat.read_bytes())
            python_flat, python_details = make_flat(independent_path.read_bytes())
            python = coverage(python_flat)
            ys, xs = np.where(cpp != oracle)
            cpp_python_difference = int(np.count_nonzero(cpp != python))
            record = dict(case=label, geometry=geometry, layer=layer,
                          independentPathSha256=digest(independent_path.read_bytes()),
                          cppFlatPathSha256=digest(cpp_flat.read_bytes()),
                          cppCoverageSha256=digest(cpp.tobytes()), oracleCoverageSha256=digest(oracle_raw),
                          differentOracleCoveragePixels=int(len(xs)),
                          differentPythonCoveragePixels=cpp_python_difference,
                          cppDetails=details[layer], pythonDetails=python_details,
                          first=[dict(x=int(x), y=int(y), cpp=int(cpp[y, x]), oracle=int(oracle[y, x]))
                                 for y, x in zip(ys[:12], xs[:12])])
            records.append(record)
            masks[label, layer] = cpp
    guard_command = [HERE / 'ellipse_curve_guard_probe.exe']
    guard = call(guard_command)
    commands.append(list(map(str, guard_command)))
    guard_results = json.loads(guard.stdout)
    (HERE / 'guard-api-r1.json').write_text(json.dumps(guard_results, indent=2) + '\n', encoding='utf-8')
    cli_refusals = []
    for label, geometry in [
        ('x0', ('0', '100', '200', '100')),
        ('small-width', ('100', '100', '99', '100')),
        ('outside-right', ('700', '100', '200', '100')),
        ('outside-bottom', ('100', '400', '200', '100')),
        ('fractional-x', ('1.5', '100', '200', '100')),
        ('overflow-x', ('9223372036854775807', '100', '200', '100')),
    ]:
        prefix = ARTIFACTS / ('refused-' + label)
        command = [HERE / 'ellipse_curve_probe.exe', prefix, *geometry]
        result = call(command, 3)
        commands.append(list(map(str, command)))
        outputs = list(ARTIFACTS.glob(prefix.name + '*'))
        if outputs:
            raise AssertionError('Refused CLI geometry wrote output: ' + str(outputs))
        cli_refusals.append(dict(case=label, geometry=geometry, exitCode=result.returncode,
                                 outputFiles=0, reason=result.stderr.decode(errors='replace').strip()))
    native_path = WORK / 'docs/stage5-evidence/native/audit/audit-ellipse-default-r1/compiled/canonical-default/SheetPixel.dat'
    decoded = TEMP / 'default-native.rgb565'
    command = [ROOT.parents[1] / 'KinSealStudio/docs/stage3-evidence/native/tools/lzo_decode.exe', native_path, decoded, 768000]
    call(command)
    commands.append(list(map(str, command)))
    native_raw = decoded.read_bytes()
    native = np.frombuffer(native_raw, '<u2').reshape(480, 800)
    actual = compose(masks['default', 'fill'], masks['default', 'stroke'])
    native_differences = int(np.count_nonzero(native != actual))
    result = dict(scope='Eight ellipse geometry diagnostics, fill/stroke coverage compared with an external Qt4 oracle; only retained default is native-frame validated.',
                  cases=records, allOracleCoverageEqual=all(item['differentOracleCoveragePixels'] == 0 for item in records),
                  allPythonCoverageEqual=all(item['differentPythonCoveragePixels'] == 0 for item in records),
                  retainedNativeDefault=dict(differentPixels=native_differences,
                                             nativeFrameSha256=digest(native_raw),
                                             candidateFrameSha256=digest(actual.tobytes()), bytes=len(native_raw)),
                  apiGuardFailures=guard_results['failed'], cliRefusals=cli_refusals,
                  nativeProcessLaunched=False, usbAccessed=False, productionChanged=False,
                  historicalLibrarySourcesLinkedIntoCandidate=False, historicalXYCrossTermPreserved=True,
                  negativeCoordinatesSupported=False, maximumInputElements=512,
                  maximumOutputElements=4096, maximumSubdivisionDepth=8)
    (HERE / 'cpp-ellipse-coverage-r1.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    (HERE / 'run-commands-r1.json').write_text(json.dumps(dict(commands=commands), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(cases=len(records), oracleDifferences=[(item['case'], item['layer'], item['differentOracleCoveragePixels']) for item in records],
                          pythonDifferences=sum(item['differentPythonCoveragePixels'] for item in records),
                          nativeDefaultDifference=native_differences, apiGuardFailures=guard_results['failed'], cliRefusals=len(cli_refusals))))
    if not result['allOracleCoverageEqual'] or not result['allPythonCoverageEqual'] or native_differences or guard_results['failed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
