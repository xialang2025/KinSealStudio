"""Build the standalone independent curve candidate without historical library sources."""
from pathlib import Path
import hashlib,json,os,subprocess
here=Path(__file__).resolve().parent
qt=Path('G:/01_Professional/QT6/Installed/6.12.0/mingw_64');mingw=Path('G:/01_Professional/QT6/Installed/Tools/mingw1310_64/bin')
env=os.environ.copy();env['PATH']=str(mingw)+';'+str(qt/'bin')+';'+env.get('PATH','')
for key in ('TEMP','TMP','TMPDIR'):env[key]=str(here/'temp')
records=[]
for target in ('ellipse_curve_probe','ellipse_curve_guard_probe'):
 args=[str(mingw/'g++.exe'),'-std=c++17','-O2','-Wall','-Wextra','-Wconversion','-DQT_NO_DEBUG','-isystem',str(qt/'include'),'-isystem',str(qt/'include/QtCore'),'-isystem',str(qt/'include/QtGui'),str(here/'ellipse_curve_candidate.cpp'),str(here/(target+'.cpp')),'-L'+str(qt/'lib'),'-lQt6Gui','-lQt6Core','-o',str(here/(target+'.exe'))]
 r=subprocess.run(args,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
 log=here/(target+'-build-r2.log');log.write_bytes(r.stdout+r.stderr)
 records.append(dict(command=args,exitCode=r.returncode,log=log.name,logSha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 if r.returncode:raise RuntimeError((r.returncode,(r.stdout+r.stderr).decode(errors='replace')))
(here/'build-command-r2.json').write_text(json.dumps(dict(commands=records,tempDirectory=str(here/'temp'),nativeLaunched=False,usbAccessed=False,productionChanged=False,historicalLibrarySourcesLinked=False),indent=2)+'\n',encoding='utf-8')
print(json.dumps([(r['exitCode'],r['log']) for r in records]))
