#include "ellipse_curve_candidate.h"

#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>

/******************************************************************************
 * Function Name   : main
 * Description     : Verify explicit refusals and atomic caller outputs through the reusable API.
 * Input Parameters: None.
 * Return Value    : Zero if every guard case is refused with output and stats preserved.
 * Date            : 2026.11.14
 ******************************************************************************/
int main(int argc, char **argv) //20261114-5 add
{
    QCoreApplication app(argc, argv);
    QPainterPath path;
    QPainterPath output;
    QPainterPath sentinel;
    EllipseFlattenStats stats;
    QJsonArray results;
    QJsonObject result;
    QString error;
    QString label;
    qint64 caseIndex;
    qint64 index;
    qint64 failed;
    bool accepted;
    bool preserved;
    QByteArray raw;

    sentinel.moveTo(111, 111);
    sentinel.lineTo(112, 112);
    failed = 0;
    for (caseIndex = 0; caseIndex < 6; caseIndex++)
    {
        path = QPainterPath();
        if (caseIndex == 0)
        {
            label = QStringLiteral("null-output");
            path.addEllipse(QRectF(100, 100, 200, 100));
        }
        else if (caseIndex == 1)
        {
            label = QStringLiteral("empty-input");
        }
        else if (caseIndex == 2)
        {
            label = QStringLiteral("negative-control-point");
            path.moveTo(-0.5, 100);
            path.lineTo(100, 100);
        }
        else if (caseIndex == 3)
        {
            label = QStringLiteral("outside-control-point");
            path.moveTo(100, 100);
            path.lineTo(801, 100);
        }
        else if (caseIndex == 4)
        {
            label = QStringLiteral("input-element-budget");
            path.moveTo(100, 100);
            for (index = 0; index < 513; index++)
            {
                path.lineTo(100 + qreal(index % 2), 100 + qreal(index % 3));
            }
        }
        else
        {
            label = QStringLiteral("generated-element-budget");
            path.moveTo(200, 200);
            for (index = 0; index < 170; index++)
            {
                path.cubicTo(700, 300, 100, 100, 200, 200);
            }
        }
        output = sentinel;
        stats.inputElements = 987654;
        error = QStringLiteral("old error");
        accepted = flattenHistoricalEllipseCandidate(path, caseIndex == 0 ? nullptr : &output, &error, &stats);
        preserved = output == sentinel && stats.inputElements == 987654;
        result = QJsonObject();
        result.insert(QStringLiteral("case"), label);
        result.insert(QStringLiteral("accepted"), accepted);
        result.insert(QStringLiteral("callerOutputAndStatsPreserved"), preserved);
        result.insert(QStringLiteral("inputElements"), path.elementCount());
        result.insert(QStringLiteral("reason"), error);
        results.append(result);
        if (accepted || !preserved || error.isEmpty() || error == QStringLiteral("old error"))
        {
            failed++;
        }
    }
    result = QJsonObject();
    result.insert(QStringLiteral("cases"), results);
    result.insert(QStringLiteral("failed"), failed);
    raw = QJsonDocument(result).toJson(QJsonDocument::Indented);
    std::fwrite(raw.constData(), 1, size_t(raw.size()), stdout);
    return failed == 0 ? 0 : 1;
}
